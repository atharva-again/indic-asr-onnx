from .transcriber import IndicConformerTranscriber
from ._version import __version__

__all__ = ["IndicConformerTranscriber", "__version__"]